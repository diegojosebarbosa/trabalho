package br.edu.up.jpa;

import br.edu.up.jpa.dominio.Produto;
import br.edu.up.jpa.dominio.Fornecedor_Produto;
import br.edu.up.jpa.repository.ProdutoRepository;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
public class CrudRepository {

}
