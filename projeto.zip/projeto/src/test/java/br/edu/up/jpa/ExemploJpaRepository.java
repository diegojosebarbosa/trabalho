package br.edu.up.jpa;

public class ExemploJpaRepository {

}
